import React from 'react';

function Footer() {
  return (
    <nav>
      <ul>
        <li><a href="./..">Home</a></li>
        <li><a href="./..">Home</a></li>
        <li><a href="./../module-page">Modules</a></li>
        <li> About</li>
      </ul>
    </nav>
  );
}

export default Footer;
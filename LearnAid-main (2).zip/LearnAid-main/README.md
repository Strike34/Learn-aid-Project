# LearnAid
SWE Project Group 31
 
# installing dependencies
install node before hand
1. install express
npm i express

npm install react-scripts


npm install http-proxy-middleware --save

npm install react-router-dom

npm run start



